/*
  # ROHID MART POS System Database Schema

  1. New Tables
    - `products`
      - `id` (uuid, primary key)
      - `name` (text, product name)
      - `category` (text, product category)
      - `buying_price` (integer, price in rupiah)
      - `selling_price` (integer, price in rupiah)  
      - `stock` (integer, current stock quantity)
      - `created_at` (timestamp)

    - `purchases`
      - `id` (uuid, primary key)
      - `product_id` (foreign key to products)
      - `quantity` (integer, quantity purchased)
      - `unit_price` (integer, purchase price per unit)
      - `supplier` (text, supplier name)
      - `date` (timestamp, purchase date)

    - `sales`
      - `id` (uuid, primary key)
      - `product_id` (foreign key to products)
      - `quantity` (integer, quantity sold)
      - `date` (timestamp, sale date)
      - `remarks` (text, optional sale notes)

  2. Security
    - Enable RLS on all tables
    - Allow all operations for anonymous users (no authentication required)

  3. Functions
    - `update_product_stock` - Helper function to update product stock
*/

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  buying_price integer NOT NULL DEFAULT 0,
  selling_price integer NOT NULL DEFAULT 0,
  stock integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create purchases table
CREATE TABLE IF NOT EXISTS purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 0,
  unit_price integer NOT NULL DEFAULT 0,
  supplier text DEFAULT '',
  date timestamptz DEFAULT now()
);

-- Create sales table
CREATE TABLE IF NOT EXISTS sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 0,
  date timestamptz DEFAULT now(),
  remarks text DEFAULT ''
);

-- Enable Row Level Security
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;

-- Create policies to allow all operations (no authentication required)
CREATE POLICY "Allow all operations on products"
  ON products
  FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on purchases"
  ON purchases
  FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on sales"
  ON sales
  FOR ALL
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Create function to update product stock
CREATE OR REPLACE FUNCTION update_product_stock(
  product_id uuid,
  quantity_change integer
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE products 
  SET stock = stock + quantity_change
  WHERE id = product_id;
  
  -- Ensure stock doesn't go negative
  UPDATE products 
  SET stock = 0 
  WHERE id = product_id AND stock < 0;
END;
$$;

-- Insert sample data for testing
INSERT INTO products (name, category, buying_price, selling_price, stock) VALUES
  ('Indomie Goreng', 'Makanan Instan', 2500, 3000, 50),
  ('Teh Pucuk', 'Minuman', 3000, 4000, 30),
  ('Sabun Mandi', 'Kebersihan', 8000, 10000, 20),
  ('Pensil 2B', 'Alat Tulis', 1500, 2000, 100),
  ('Buku Tulis', 'Alat Tulis', 3000, 4000, 25)
ON CONFLICT DO NOTHING;