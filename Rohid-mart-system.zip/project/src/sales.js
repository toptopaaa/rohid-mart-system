import { showToast } from './utils.js';

export async function loadSales() {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    const { data: sales, error } = await window.supabase
      .from('sales')
      .select(`
        *,
        products (name, selling_price, buying_price)
      `)
      .gte('date', today + 'T00:00:00')
      .lte('date', today + 'T23:59:59')
      .order('date', { ascending: false });
    
    if (error) throw error;
    
    const tbody = document.getElementById('sales-table');
    
    if (!sales || sales.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" class="px-6 py-4 text-center text-gray-500">Belum ada penjualan hari ini</td>
        </tr>
      `;
      return;
    }
    
    tbody.innerHTML = sales.map(sale => {
      const unitPrice = sale.products?.selling_price || 0;
      const buyingPrice = sale.products?.buying_price || 0;
      const total = unitPrice * sale.quantity;
      const profit = (unitPrice - buyingPrice) * sale.quantity;
      const date = new Date(sale.date);
      
      return `
        <tr class="hover:bg-gray-50">
          <td class="px-6 py-4 text-sm text-gray-900">${date.toLocaleTimeString()}</td>
          <td class="px-6 py-4">
            <div class="font-medium text-gray-900">${sale.products?.name || 'Produk Tidak Dikenal'}</div>
          </td>
          <td class="px-6 py-4 text-sm text-gray-900">${sale.quantity}</td>
          <td class="px-6 py-4 text-sm text-gray-900">Rp ${unitPrice.toLocaleString()}</td>
          <td class="px-6 py-4 text-sm text-gray-900 font-medium">Rp ${total.toLocaleString()}</td>
          <td class="px-6 py-4 text-sm text-green-600 font-medium">Rp ${profit.toLocaleString()}</td>
          <td class="px-6 py-4 text-sm text-gray-500">${sale.remarks || '-'}</td>
        </tr>
      `;
    }).join('');
    
  } catch (error) {
    console.error('Error loading sales:', error);
    showToast('Gagal memuat data penjualan', 'error');
  }
}