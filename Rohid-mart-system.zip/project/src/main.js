import './index.css';
import { initializeSupabase } from './supabase.js';
import { loadProducts, loadProductsForDropdown } from './products.js';
import { loadPurchases } from './purchases.js';
import { loadSales } from './sales.js';
import { loadDashboard } from './dashboard.js';
import { loadReports } from './reports.js';
import { loadRestock } from './restock.js';
import { showToast } from './utils.js';

// Global variables
let currentPage = 'dashboard';
let supabase = null;

// Initialize the application
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Initialize Supabase
    supabase = await initializeSupabase();
    window.supabase = supabase;
    
    // Set default dates
    const today = new Date().toISOString().split('T')[0];
    const lastWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    document.getElementById('report-from-date').value = lastWeek;
    document.getElementById('report-to-date').value = today;
    
    // Load initial data
    await loadDashboard();
    await loadProducts();
    await loadProductsForDropdown();
    
    showToast('ROHID MART POS System initialized successfully!', 'success');
  } catch (error) {
    console.error('Failed to initialize app:', error);
    showToast('Gagal menginisialisasi aplikasi. Periksa koneksi internet Anda.', 'error');
  }
});

// Navigation functions
window.showPage = (pageId) => {
  // Hide all pages
  document.querySelectorAll('.page').forEach(page => {
    page.classList.add('hidden');
  });
  
  // Show selected page
  document.getElementById(`${pageId}-page`).classList.remove('hidden');
  
  // Update navigation state
  document.querySelectorAll('.nav-link, .nav-link-mobile').forEach(link => {
    link.classList.remove('bg-emerald-700');
  });
  
  // Add active state to current nav item
  const navButtons = document.querySelectorAll('.nav-link, .nav-link-mobile');
  navButtons.forEach(button => {
    const pageNames = {
      'dashboard': 'beranda',
      'products': 'produk', 
      'purchases': 'pembelian',
      'sales': 'penjualan',
      'reports': 'laporan',
      'restock': 'stok ulang'
    };
    if (button.textContent.toLowerCase() === pageNames[pageId]) {
      button.classList.add('bg-emerald-700');
    }
  });
  
  currentPage = pageId;
  
  // Load page-specific data
  switch (pageId) {
    case 'dashboard':
      loadDashboard();
      break;
    case 'products':
      loadProducts();
      break;
    case 'purchases':
      loadPurchases();
      loadProductsForDropdown('purchase-product');
      break;
    case 'sales':
      loadSales();
      loadProductsForDropdown('sale-product');
      break;
    case 'reports':
      loadReports();
      break;
    case 'restock':
      loadRestock();
      break;
  }
  
  // Close mobile menu
  document.getElementById('mobile-menu').classList.add('hidden');
};

window.toggleMobileMenu = () => {
  const menu = document.getElementById('mobile-menu');
  menu.classList.toggle('hidden');
};

// Product management functions
window.openProductModal = (productId = null) => {
  const modal = document.getElementById('product-modal');
  const title = document.getElementById('product-modal-title');
  const form = document.getElementById('product-form');
  
  if (productId) {
    title.textContent = 'Edit Produk';
    // Load product data for editing
    loadProductForEdit(productId);
  } else {
    title.textContent = 'Tambah Produk Baru';
    form.reset();
    document.getElementById('product-id').value = '';
  }
  
  modal.classList.remove('hidden');
  modal.classList.add('flex');
};

window.closeProductModal = () => {
  const modal = document.getElementById('product-modal');
  modal.classList.add('hidden');
  modal.classList.remove('flex');
};

async function loadProductForEdit(productId) {
  try {
    const { data: product, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .single();
    
    if (error) throw error;
    
    document.getElementById('product-id').value = product.id;
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-category').value = product.category;
    document.getElementById('product-buying-price').value = product.buying_price;
    document.getElementById('product-selling-price').value = product.selling_price;
    document.getElementById('product-stock').value = product.stock;
  } catch (error) {
    console.error('Error loading product:', error);
    showToast('Gagal memuat data produk', 'error');
  }
}

// Form submissions
document.getElementById('product-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const productId = document.getElementById('product-id').value;
  const productData = {
    name: document.getElementById('product-name').value,
    category: document.getElementById('product-category').value,
    buying_price: parseInt(document.getElementById('product-buying-price').value),
    selling_price: parseInt(document.getElementById('product-selling-price').value),
    stock: parseInt(document.getElementById('product-stock').value)
  };
  
  try {
    let result;
    if (productId) {
      // Update existing product
      result = await supabase
        .from('products')
        .update(productData)
        .eq('id', productId);
    } else {
      // Create new product
      result = await supabase
        .from('products')
        .insert([productData]);
    }
    
    if (result.error) throw result.error;
    
    showToast(`Produk berhasil ${productId ? 'diperbarui' : 'ditambahkan'}!`, 'success');
    closeProductModal();
    loadProducts();
    loadProductsForDropdown();
  } catch (error) {
    console.error('Error saving product:', error);
    showToast('Gagal menyimpan produk', 'error');
  }
});

document.getElementById('purchase-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const productId = document.getElementById('purchase-product').value;
  const quantity = parseInt(document.getElementById('purchase-quantity').value);
  const unitPrice = parseInt(document.getElementById('purchase-price').value);
  const supplier = document.getElementById('purchase-supplier').value;
  
  if (!productId || !quantity || !unitPrice) {
    showToast('Harap isi semua field yang wajib', 'error');
    return;
  }
  
  try {
    // Start transaction
    const { data: purchase, error: purchaseError } = await supabase
      .from('purchases')
      .insert([{
        product_id: productId,
        quantity: quantity,
        unit_price: unitPrice,
        supplier: supplier || 'Unknown',
        date: new Date().toISOString()
      }])
      .select()
      .single();
    
    if (purchaseError) throw purchaseError;
    
    // Update product stock
    const { error: stockError } = await supabase.rpc('update_product_stock', {
      product_id: productId,
      quantity_change: quantity
    });
    
    if (stockError) throw stockError;
    
    showToast('Pembelian berhasil dicatat!', 'success');
    document.getElementById('purchase-form').reset();
    loadPurchases();
    loadProducts();
    loadDashboard();
  } catch (error) {
    console.error('Error recording purchase:', error);
    showToast('Gagal mencatat pembelian', 'error');
  }
});

document.getElementById('sale-product').addEventListener('change', updateSaleSummary);
document.getElementById('sale-quantity').addEventListener('input', updateSaleSummary);

async function updateSaleSummary() {
  const productId = document.getElementById('sale-product').value;
  const quantity = parseInt(document.getElementById('sale-quantity').value) || 0;
  
  if (!productId || !quantity) {
    document.getElementById('sale-summary').classList.add('hidden');
    return;
  }
  
  try {
    const { data: product, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .single();
    
    if (error) throw error;
    
    const totalPrice = product.selling_price * quantity;
    const profit = (product.selling_price - product.buying_price) * quantity;
    
    document.getElementById('available-stock').textContent = product.stock;
    document.getElementById('unit-price').textContent = `Rp ${product.selling_price.toLocaleString()}`;
    document.getElementById('total-price').textContent = `Rp ${totalPrice.toLocaleString()}`;
    document.getElementById('sale-profit').textContent = `Rp ${profit.toLocaleString()}`;
    
    // Show warning if quantity exceeds stock
    if (quantity > product.stock) {
      document.getElementById('available-stock').classList.add('text-red-600');
      showToast(`Peringatan: Hanya tersedia ${product.stock} unit!`, 'warning');
    } else {
      document.getElementById('available-stock').classList.remove('text-red-600');
    }
    
    document.getElementById('sale-summary').classList.remove('hidden');
  } catch (error) {
    console.error('Error loading product:', error);
  }
}

document.getElementById('sales-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const productId = document.getElementById('sale-product').value;
  const quantity = parseInt(document.getElementById('sale-quantity').value);
  const remarks = document.getElementById('sale-remarks').value;
  
  if (!productId || !quantity) {
    showToast('Harap pilih produk dan jumlah', 'error');
    return;
  }
  
  try {
    // Check stock availability
    const { data: product, error: productError } = await supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .single();
    
    if (productError) throw productError;
    
    if (quantity > product.stock) {
      showToast(`Stok tidak cukup! Hanya tersedia ${product.stock} unit.`, 'error');
      return;
    }
    
    // Record sale
    const { error: saleError } = await supabase
      .from('sales')
      .insert([{
        product_id: productId,
        quantity: quantity,
        remarks: remarks || null,
        date: new Date().toISOString()
      }]);
    
    if (saleError) throw saleError;
    
    // Update product stock
    const { error: stockError } = await supabase.rpc('update_product_stock', {
      product_id: productId,
      quantity_change: -quantity
    });
    
    if (stockError) throw stockError;
    
    showToast('Penjualan berhasil dicatat!', 'success');
    document.getElementById('sales-form').reset();
    document.getElementById('sale-summary').classList.add('hidden');
    loadSales();
    loadProducts();
    loadDashboard();
  } catch (error) {
    console.error('Error recording sale:', error);
    showToast('Gagal mencatat penjualan', 'error');
  }
});

// Search and filter functions
document.getElementById('product-search').addEventListener('input', filterProducts);
document.getElementById('category-filter').addEventListener('change', filterProducts);
document.getElementById('stock-filter').addEventListener('change', filterProducts);

function filterProducts() {
  const search = document.getElementById('product-search').value.toLowerCase();
  const categoryFilter = document.getElementById('category-filter').value;
  const stockFilter = document.getElementById('stock-filter').value;
  
  const rows = document.querySelectorAll('#products-table tr[data-product-id]');
  
  rows.forEach(row => {
    const name = row.querySelector('[data-name]').textContent.toLowerCase();
    const category = row.querySelector('[data-category]').textContent;
    const stock = parseInt(row.querySelector('[data-stock]').textContent);
    
    let showRow = true;
    
    // Search filter
    if (search && !name.includes(search)) {
      showRow = false;
    }
    
    // Category filter
    if (categoryFilter && category !== categoryFilter) {
      showRow = false;
    }
    
    // Stock filter
    if (stockFilter === 'low' && stock >= 5) {
      showRow = false;
    } else if (stockFilter === 'out' && stock > 0) {
      showRow = false;
    }
    
    row.style.display = showRow ? '' : 'none';
  });
}

// Delete product function
window.deleteProduct = async (productId) => {
  if (!confirm('Apakah Anda yakin ingin menghapus produk ini?')) return;
  
  try {
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', productId);
    
    if (error) throw error;
    
    showToast('Produk berhasil dihapus!', 'success');
    loadProducts();
    loadProductsForDropdown();
  } catch (error) {
    console.error('Error deleting product:', error);
    showToast('Gagal menghapus produk', 'error');
  }
};

// Report functions
window.generateReport = () => {
  loadReports();
};

window.exportToCSV = async () => {
  const fromDate = document.getElementById('report-from-date').value;
  const toDate = document.getElementById('report-to-date').value;
  
  if (!fromDate || !toDate) {
    showToast('Harap pilih rentang tanggal', 'error');
    return;
  }
  
  try {
    // Fetch sales data
    const { data: sales, error: salesError } = await supabase
      .from('sales')
      .select(`
        *,
        products (name, selling_price, buying_price)
      `)
      .gte('date', fromDate + 'T00:00:00')
      .lte('date', toDate + 'T23:59:59')
      .order('date', { ascending: false });
    
    if (salesError) throw salesError;
    
    // Fetch purchases data
    const { data: purchases, error: purchasesError } = await supabase
      .from('purchases')
      .select(`
        *,
        products (name)
      `)
      .gte('date', fromDate + 'T00:00:00')
      .lte('date', toDate + 'T23:59:59')
      .order('date', { ascending: false });
    
    if (purchasesError) throw purchasesError;
    
    // Prepare CSV data
    let csvContent = 'Tanggal,Jenis,Produk,Jumlah,Harga Satuan,Total,Keuntungan,Keterangan\n';
    
    // Add sales
    sales.forEach(sale => {
      const total = sale.products.selling_price * sale.quantity;
      const profit = (sale.products.selling_price - sale.products.buying_price) * sale.quantity;
      csvContent += `${new Date(sale.date).toLocaleDateString()},Penjualan,"${sale.products.name}",${sale.quantity},${sale.products.selling_price},${total},${profit},"${sale.remarks || ''}"\n`;
    });
    
    // Add purchases
    purchases.forEach(purchase => {
      const total = purchase.unit_price * purchase.quantity;
      csvContent += `${new Date(purchase.date).toLocaleDateString()},Pembelian,"${purchase.products.name}",${purchase.quantity},${purchase.unit_price},${total},0,"${purchase.supplier}"\n`;
    });
    
    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rohid-mart-report-${fromDate}-to-${toDate}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    showToast('Laporan berhasil diekspor!', 'success');
  } catch (error) {
    console.error('Error exporting report:', error);
    showToast('Gagal mengekspor laporan', 'error');
  }
};

// Restock functions
window.generatePurchaseOrder = () => {
  const rows = document.querySelectorAll('#restock-table tr[data-priority]');
  let orderText = 'DAFTAR BELANJA - ROHID MART\n';
  orderText += `Dibuat: ${new Date().toLocaleDateString()}\n\n`;
  
  rows.forEach(row => {
    const product = row.cells[0].textContent;
    const suggestedQty = row.cells[4].textContent;
    const estimatedCost = row.cells[5].textContent;
    orderText += `${product}: ${suggestedQty} units - ${estimatedCost}\n`;
  });
  
  // Create and download text file
  const blob = new Blob([orderText], { type: 'text/plain' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `purchase-order-${new Date().toISOString().split('T')[0]}.txt`;
  a.click();
  window.URL.revokeObjectURL(url);
  
  showToast('Daftar belanja berhasil dibuat!', 'success');
};

// Initialize dashboard as default page
showPage('dashboard');