import { showToast } from './utils.js';

export async function loadRestock() {
  try {
    // Get last 3 days date range
    const threeDaysAgo = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const today = new Date().toISOString().split('T')[0];
    
    // Load products
    const { data: products, error: productsError } = await window.supabase
      .from('products')
      .select('*')
      .order('name');
    
    if (productsError) throw productsError;
    
    // Load sales for last 3 days
    const { data: sales, error: salesError } = await window.supabase
      .from('sales')
      .select('product_id, quantity')
      .gte('date', threeDaysAgo + 'T00:00:00')
      .lte('date', today + 'T23:59:59');
    
    if (salesError) throw salesError;
    
    // Calculate sales statistics for each product
    const salesStats = {};
    sales.forEach(sale => {
      if (!salesStats[sale.product_id]) {
        salesStats[sale.product_id] = 0;
      }
      salesStats[sale.product_id] += sale.quantity;
    });
    
    // Generate restock suggestions
    const restockSuggestions = [];
    let needsRestock = 0;
    let criticalStock = 0;
    
    products.forEach(product => {
      const totalSold = salesStats[product.id] || 0;
      const dailyAverage = totalSold / 3; // 3 days average
      const currentStock = product.stock;
      
      // If current stock < average daily sales × 2, suggest restock
      const minimumStock = Math.ceil(dailyAverage * 2);
      
      if (currentStock <= minimumStock || currentStock < 5) {
        const suggestedQuantity = Math.max(minimumStock - currentStock + 7, 10); // Add 7 days buffer, minimum 10
        const estimatedCost = suggestedQuantity * product.buying_price;
        
        let priority = 'Low';
        if (currentStock === 0) {
          priority = 'Critical';
          criticalStock++;
        } else if (currentStock < dailyAverage || currentStock < 3) {
          priority = 'High';
          needsRestock++;
        } else {
          needsRestock++;
        }
        
        const daysUntilEmpty = dailyAverage > 0 ? Math.floor(currentStock / dailyAverage) : 999;
        
        restockSuggestions.push({
          product,
          currentStock,
          dailyAverage: dailyAverage.toFixed(1),
          daysUntilEmpty,
          suggestedQuantity,
          estimatedCost,
          priority
        });
      }
    });
    
    // Sort by priority (Critical > High > Low) and then by days until empty
    restockSuggestions.sort((a, b) => {
      const priorityOrder = { 'Critical': 3, 'High': 2, 'Low': 1 };
      if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      return a.daysUntilEmpty - b.daysUntilEmpty;
    });
    
    // Update statistics
    document.getElementById('products-analyzed').textContent = products.length;
    document.getElementById('needs-restock').textContent = needsRestock;
    document.getElementById('critical-stock').textContent = criticalStock;
    
    // Load restock table
    loadRestockTable(restockSuggestions);
    
  } catch (error) {
    console.error('Error loading restock suggestions:', error);
    showToast('Gagal memuat saran stok ulang', 'error');
  }
}

function loadRestockTable(suggestions) {
  const tbody = document.getElementById('restock-table');
  
  if (suggestions.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="px-6 py-4 text-center text-gray-500">
          Semua produk stoknya masih aman! Tidak perlu stok ulang saat ini.
        </td>
      </tr>
    `;
    return;
  }
  
  tbody.innerHTML = suggestions.map(suggestion => {
    const { product, currentStock, dailyAverage, daysUntilEmpty, suggestedQuantity, estimatedCost, priority } = suggestion;
    
    let priorityBadge = '';
    switch (priority) {
      case 'Critical':
        priorityBadge = '<span class="px-2 py-1 text-xs font-semibold bg-red-100 text-red-800 rounded-full">Kritis</span>';
        break;
      case 'High':
        priorityBadge = '<span class="px-2 py-1 text-xs font-semibold bg-yellow-100 text-yellow-800 rounded-full">Tinggi</span>';
        break;
      default:
        priorityBadge = '<span class="px-2 py-1 text-xs font-semibold bg-blue-100 text-blue-800 rounded-full">Rendah</span>';
    }
    
    const daysText = daysUntilEmpty === 999 ? 'Tidak Terbatas' : `${daysUntilEmpty} hari`;
    
    return `
      <tr data-priority="${priority}" class="hover:bg-gray-50">
        <td class="px-6 py-4">
          <div class="font-medium text-gray-900">${product.name}</div>
          <div class="text-sm text-gray-500">${product.category}</div>
        </td>
        <td class="px-6 py-4 text-sm text-gray-900">${currentStock}</td>
        <td class="px-6 py-4 text-sm text-gray-900">${dailyAverage}</td>
        <td class="px-6 py-4 text-sm text-gray-900">${daysText}</td>
        <td class="px-6 py-4 text-sm text-gray-900 font-medium">${suggestedQuantity} unit</td>
        <td class="px-6 py-4 text-sm text-gray-900">Rp ${estimatedCost.toLocaleString()}</td>
        <td class="px-6 py-4">${priorityBadge}</td>
      </tr>
    `;
  }).join('');
}