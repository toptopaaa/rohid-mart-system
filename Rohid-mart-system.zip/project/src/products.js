import { showToast } from './utils.js';

export async function loadProducts() {
  try {
    const { data: products, error } = await window.supabase
      .from('products')
      .select('*')
      .order('name');
    
    if (error) throw error;
    
    const tbody = document.getElementById('products-table');
    
    if (!products || products.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8" class="px-6 py-4 text-center text-gray-500">
            Belum ada produk. <button onclick="openProductModal()" class="text-emerald-600 hover:underline">Tambah produk pertama</button>
          </td>
        </tr>
      `;
      return;
    }
    
    tbody.innerHTML = products.map(product => {
      const stockValue = product.stock * product.buying_price;
      const isLowStock = product.stock < 5;
      const isOutOfStock = product.stock === 0;
      
      let statusBadge = '';
      if (isOutOfStock) {
        statusBadge = '<span class="px-2 py-1 text-xs font-semibold bg-red-100 text-red-800 rounded-full">Stok Habis</span>';
      } else if (isLowStock) {
        statusBadge = '<span class="px-2 py-1 text-xs font-semibold bg-yellow-100 text-yellow-800 rounded-full">Stok Menipis</span>';
      } else {
        statusBadge = '<span class="px-2 py-1 text-xs font-semibold bg-green-100 text-green-800 rounded-full">Stok Aman</span>';
      }
      
      return `
        <tr data-product-id="${product.id}" class="hover:bg-gray-50">
          <td class="px-6 py-4">
            <div class="font-medium text-gray-900" data-name>${product.name}</div>
          </td>
          <td class="px-6 py-4 text-sm text-gray-500" data-category>${product.category}</td>
          <td class="px-6 py-4 text-sm text-gray-900">Rp ${product.buying_price.toLocaleString()}</td>
          <td class="px-6 py-4 text-sm text-gray-900">Rp ${product.selling_price.toLocaleString()}</td>
          <td class="px-6 py-4 text-sm text-gray-900" data-stock>${product.stock}</td>
          <td class="px-6 py-4 text-sm text-gray-900">Rp ${stockValue.toLocaleString()}</td>
          <td class="px-6 py-4">${statusBadge}</td>
          <td class="px-6 py-4 text-sm font-medium">
            <button onclick="openProductModal('${product.id}')" class="text-emerald-600 hover:text-emerald-900 mr-3">Edit</button>
            <button onclick="deleteProduct('${product.id}')" class="text-red-600 hover:text-red-900">Hapus</button>
          </td>
        </tr>
      `;
    }).join('');
    
    // Update category filter options
    updateCategoryFilter(products);
    
  } catch (error) {
    console.error('Error loading products:', error);
    showToast('Gagal memuat produk', 'error');
  }
}

export async function loadProductsForDropdown(selectId = null) {
  try {
    const { data: products, error } = await window.supabase
      .from('products')
      .select('id, name, stock, selling_price, buying_price')
      .order('name');
    
    if (error) throw error;
    
    const selectors = selectId ? [selectId] : ['purchase-product', 'sale-product'];
    
    selectors.forEach(id => {
      const select = document.getElementById(id);
      if (select) {
        select.innerHTML = '<option value="">Pilih Produk</option>' +
          products.map(product => 
            `<option value="${product.id}" data-stock="${product.stock}" data-price="${product.selling_price}" data-buying-price="${product.buying_price}">
              ${product.name} (Stok: ${product.stock})
            </option>`
          ).join('');
      }
    });
    
  } catch (error) {
    console.error('Error loading products for dropdown:', error);
  }
}

function updateCategoryFilter(products) {
  const categories = [...new Set(products.map(p => p.category))];
  const select = document.getElementById('category-filter');
  
  select.innerHTML = '<option value="">Semua Kategori</option>' +
    categories.map(category => `<option value="${category}">${category}</option>`).join('');
}