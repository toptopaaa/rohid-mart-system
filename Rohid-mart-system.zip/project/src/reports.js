import { showToast } from './utils.js';

export async function loadReports() {
  const fromDate = document.getElementById('report-from-date').value;
  const toDate = document.getElementById('report-to-date').value;
  
  if (!fromDate || !toDate) {
    showToast('Harap pilih rentang tanggal', 'error');
    return;
  }
  
  try {
    // Load sales data
    const { data: sales, error: salesError } = await window.supabase
      .from('sales')
      .select(`
        *,
        products (name, selling_price, buying_price)
      `)
      .gte('date', fromDate + 'T00:00:00')
      .lte('date', toDate + 'T23:59:59')
      .order('date', { ascending: false });
    
    if (salesError) throw salesError;
    
    // Load purchases data
    const { data: purchases, error: purchasesError } = await window.supabase
      .from('purchases')
      .select(`
        *,
        products (name)
      `)
      .gte('date', fromDate + 'T00:00:00')
      .lte('date', toDate + 'T23:59:59')
      .order('date', { ascending: false });
    
    if (purchasesError) throw purchasesError;
    
    // Calculate totals
    const totalSalesAmount = sales.reduce((sum, sale) => {
      return sum + (sale.products?.selling_price || 0) * sale.quantity;
    }, 0);
    
    const totalPurchasesAmount = purchases.reduce((sum, purchase) => {
      return sum + purchase.unit_price * purchase.quantity;
    }, 0);
    
    const totalProfit = sales.reduce((sum, sale) => {
      const sellingPrice = sale.products?.selling_price || 0;
      const buyingPrice = sale.products?.buying_price || 0;
      return sum + (sellingPrice - buyingPrice) * sale.quantity;
    }, 0);
    
    // Update summary
    document.getElementById('report-total-sales').textContent = `Rp ${totalSalesAmount.toLocaleString()}`;
    document.getElementById('report-total-purchases').textContent = `Rp ${totalPurchasesAmount.toLocaleString()}`;
    document.getElementById('report-net-profit').textContent = `Rp ${totalProfit.toLocaleString()}`;
    
    // Load transaction table
    loadTransactionsTable(sales, purchases);
    
  } catch (error) {
    console.error('Error loading reports:', error);
    showToast('Gagal memuat laporan', 'error');
  }
}

function loadTransactionsTable(sales, purchases) {
  const tbody = document.getElementById('transactions-table');
  
  // Combine and sort transactions
  const allTransactions = [];
  
  sales.forEach(sale => {
    const total = (sale.products?.selling_price || 0) * sale.quantity;
    allTransactions.push({
      date: sale.date,
      type: 'Penjualan',
      product: sale.products?.name || 'Tidak Dikenal',
      quantity: sale.quantity,
      amount: total,
      details: sale.remarks || '-'
    });
  });
  
  purchases.forEach(purchase => {
    const total = purchase.unit_price * purchase.quantity;
    allTransactions.push({
      date: purchase.date,
      type: 'Pembelian',
      product: purchase.products?.name || 'Tidak Dikenal',
      quantity: purchase.quantity,
      amount: total,
      details: purchase.supplier || 'Tidak Diketahui'
    });
  });
  
  // Sort by date (newest first)
  allTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  if (allTransactions.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="px-6 py-4 text-center text-gray-500">Tidak ada transaksi dalam rentang tanggal yang dipilih</td>
      </tr>
    `;
    return;
  }
  
  tbody.innerHTML = allTransactions.map(transaction => {
    const date = new Date(transaction.date);
    const typeColor = transaction.type === 'Penjualan' ? 'text-green-600' : 'text-blue-600';
    
    return `
      <tr class="hover:bg-gray-50">
        <td class="px-6 py-4 text-sm text-gray-900">${date.toLocaleDateString()}</td>
        <td class="px-6 py-4">
          <span class="px-2 py-1 text-xs font-semibold rounded-full ${transaction.type === 'Penjualan' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}">
            ${transaction.type}
          </span>
        </td>
        <td class="px-6 py-4 text-sm text-gray-900">${transaction.product}</td>
        <td class="px-6 py-4 text-sm text-gray-900">${transaction.quantity}</td>
        <td class="px-6 py-4 text-sm text-gray-900 font-medium">Rp ${transaction.amount.toLocaleString()}</td>
        <td class="px-6 py-4 text-sm text-gray-500">${transaction.details}</td>
      </tr>
    `;
  }).join('');
}