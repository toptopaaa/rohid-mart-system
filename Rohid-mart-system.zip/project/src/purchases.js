import { showToast } from './utils.js';

export async function loadPurchases() {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    const { data: purchases, error } = await window.supabase
      .from('purchases')
      .select(`
        *,
        products (name)
      `)
      .gte('date', today + 'T00:00:00')
      .lte('date', today + 'T23:59:59')
      .order('date', { ascending: false });
    
    if (error) throw error;
    
    const tbody = document.getElementById('purchases-table');
    
    if (!purchases || purchases.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6" class="px-6 py-4 text-center text-gray-500">Belum ada pembelian hari ini</td>
        </tr>
      `;
      return;
    }
    
    tbody.innerHTML = purchases.map(purchase => {
      const total = purchase.unit_price * purchase.quantity;
      const date = new Date(purchase.date);
      
      return `
        <tr class="hover:bg-gray-50">
          <td class="px-6 py-4 text-sm text-gray-900">${date.toLocaleTimeString()}</td>
          <td class="px-6 py-4">
            <div class="font-medium text-gray-900">${purchase.products?.name || 'Produk Tidak Dikenal'}</div>
          </td>
          <td class="px-6 py-4 text-sm text-gray-900">${purchase.quantity}</td>
          <td class="px-6 py-4 text-sm text-gray-900">Rp ${purchase.unit_price.toLocaleString()}</td>
          <td class="px-6 py-4 text-sm text-gray-900 font-medium">Rp ${total.toLocaleString()}</td>
          <td class="px-6 py-4 text-sm text-gray-500">${purchase.supplier || 'Tidak Diketahui'}</td>
        </tr>
      `;
    }).join('');
    
  } catch (error) {
    console.error('Error loading purchases:', error);
    showToast('Gagal memuat data pembelian', 'error');
  }
}