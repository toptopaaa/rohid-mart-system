import { showToast } from './utils.js';

export async function loadDashboard() {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Load today's sales
    const { data: todaySales, error: salesError } = await window.supabase
      .from('sales')
      .select(`
        quantity,
        products (selling_price, buying_price)
      `)
      .gte('date', today + 'T00:00:00')
      .lte('date', today + 'T23:59:59');
    
    if (salesError) throw salesError;
    
    // Load today's purchases
    const { data: todayPurchases, error: purchasesError } = await window.supabase
      .from('purchases')
      .select('quantity, unit_price')
      .gte('date', today + 'T00:00:00')
      .lte('date', today + 'T23:59:59');
    
    if (purchasesError) throw purchasesError;
    
    // Load products for stock value and alerts
    const { data: products, error: productsError } = await window.supabase
      .from('products')
      .select('*')
      .order('name');
    
    if (productsError) throw productsError;
    
    // Calculate totals
    const totalSales = todaySales.reduce((sum, sale) => {
      return sum + (sale.products?.selling_price || 0) * sale.quantity;
    }, 0);
    
    const totalPurchases = todayPurchases.reduce((sum, purchase) => {
      return sum + purchase.unit_price * purchase.quantity;
    }, 0);
    
    const totalProfit = todaySales.reduce((sum, sale) => {
      const sellingPrice = sale.products?.selling_price || 0;
      const buyingPrice = sale.products?.buying_price || 0;
      return sum + (sellingPrice - buyingPrice) * sale.quantity;
    }, 0);
    
    const totalStockValue = products.reduce((sum, product) => {
      return sum + product.stock * product.buying_price;
    }, 0);
    
    // Update dashboard stats
    document.getElementById('today-sales').textContent = `Rp ${totalSales.toLocaleString()}`;
    document.getElementById('today-purchases').textContent = `Rp ${totalPurchases.toLocaleString()}`;
    document.getElementById('today-profit').textContent = `Rp ${totalProfit.toLocaleString()}`;
    document.getElementById('total-stock-value').textContent = `Rp ${totalStockValue.toLocaleString()}`;
    
    // Load top selling products
    await loadTopProducts();
    
    // Load low stock alerts
    loadLowStockAlerts(products);
    
  } catch (error) {
    console.error('Error loading dashboard:', error);
    showToast('Gagal memuat data beranda', 'error');
  }
}

async function loadTopProducts() {
  try {
    const last7Days = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    const { data: sales, error } = await window.supabase
      .from('sales')
      .select(`
        quantity,
        product_id,
        products (name)
      `)
      .gte('date', last7Days + 'T00:00:00');
    
    if (error) throw error;
    
    // Group sales by product
    const productSales = {};
    sales.forEach(sale => {
      const productId = sale.product_id;
      if (!productSales[productId]) {
        productSales[productId] = {
          name: sale.products?.name || 'Unknown',
          totalQuantity: 0
        };
      }
      productSales[productId].totalQuantity += sale.quantity;
    });
    
    // Sort by quantity and get top 5
    const topProducts = Object.values(productSales)
      .sort((a, b) => b.totalQuantity - a.totalQuantity)
      .slice(0, 5);
    
    const container = document.getElementById('top-products');
    
    if (topProducts.length === 0) {
      container.innerHTML = '<p class="text-gray-500">Belum ada data penjualan</p>';
      return;
    }
    
    container.innerHTML = topProducts.map((product, index) => `
      <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
        <div class="flex items-center space-x-3">
          <div class="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
            <span class="text-emerald-600 font-semibold text-sm">${index + 1}</span>
          </div>
          <span class="font-medium text-gray-900">${product.name}</span>
        </div>
        <span class="text-sm text-gray-600">${product.totalQuantity} terjual</span>
      </div>
    `).join('');
    
  } catch (error) {
    console.error('Error loading top products:', error);
  }
}

function loadLowStockAlerts(products) {
  const lowStockProducts = products.filter(product => product.stock < 5);
  const container = document.getElementById('low-stock-alert');
  
  if (lowStockProducts.length === 0) {
    container.innerHTML = '<p class="text-gray-500">Semua produk stoknya masih aman</p>';
    return;
  }
  
  container.innerHTML = lowStockProducts.map(product => {
    const isOutOfStock = product.stock === 0;
    const statusClass = isOutOfStock ? 'text-red-600' : 'text-yellow-600';
    const statusText = isOutOfStock ? 'Stok Habis' : 'Stok Menipis';
    
    return `
      <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
        <div>
          <div class="font-medium text-gray-900">${product.name}</div>
          <div class="text-sm text-gray-600">${product.category}</div>
        </div>
        <div class="text-right">
          <div class="text-sm font-medium ${statusClass}">${statusText}</div>
          <div class="text-sm text-gray-600">${product.stock} unit</div>
        </div>
      </div>
    `;
  }).join('');
}